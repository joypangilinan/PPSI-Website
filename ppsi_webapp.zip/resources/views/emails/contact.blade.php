
<h3>New E-mail From {{$emailadd}}</h3>
<h4>Message: </h4>
<p style="text-indent: 50px; font-size: 13px;">{{ $bodyMessage }}</p>
<h4>-{{ $name }}</h4>