<?php $__env->startComponent('mail::message'); ?>
# From: <?php echo e($data['email']); ?>

 
 <br>
<?php echo e($data['bodyMessage']); ?>  
<br>

Sender Name,<br>
**<?php echo e($data['name']); ?>**
<?php echo $__env->renderComponent(); ?>
