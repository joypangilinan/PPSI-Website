
<h3>New E-mail From <?php echo e($emailadd); ?></h3>
<h4>Message: </h4>
<p style="text-indent: 50px; font-size: 13px;"><?php echo e($bodyMessage); ?></p>
<h4>-<?php echo e($name); ?></h4>